import json
import random

# List of sample English words (you can replace these with your own list)
english_words = ["love", "peace", "joy", "strength", "wisdom", "power", "happiness", "friendship", "courage", "hope"] * 100  # Just an example

# Sample Yoruba translations, synonyms, and antonyms (replace these with actual translations)
yoruba_meanings = ["ifẹ", "alafia", "ayọ", "agbara", "ọgbọn", "agbára", "idunnu", "ọrẹ", "akíkanjú", "ireti"]
yoruba_synonyms = [["ifẹ", "mimọ"], ["alafia", "iru"], ["ayọ", "inurere"], ["agbara", "kíkan"], ["ọgbọn", "oye"],
                   ["agbára", "alágbára"], ["idunnu", "ayọ"], ["ọrẹ", "ajọṣepọ"], ["akíkanjú", "otitọ"], ["ireti", "ojuṣe"]]
yoruba_antonyms = [["ikorira", "ibinu"], ["ijakadi", "ojútùú"], ["ibanujẹ", "arun"], ["aláìlera", "ojiji"],
                   ["ojiji", "aburu"], ["alagbara", "aláìlera"], ["arun", "ìbànújẹ"], ["ẹnìyàn tó korira", "ikotun"],
                   ["ìbànújẹ", "aláìlera"], ["ajọṣepọ", "aláìlera"]]

# Generate the dictionary data
dictionary_data = {"words": []}

for i in range(1000):
    word = random.choice(english_words)
    meaning = random.choice(yoruba_meanings)
    synonyms = random.choice(yoruba_synonyms)
    antonyms = random.choice(yoruba_antonyms)

    entry = {
        "word": word,
        "meaning": meaning,
        "synonyms": synonyms,
        "antonyms": antonyms
    }

    dictionary_data["words"].append(entry)

# Save to dictionary.json
with open("dictionary.json", "w", encoding="utf-8") as f:
    json.dump(dictionary_data, f, ensure_ascii=False, indent=4)

print("Generated 1000 words for dictionary.json")
